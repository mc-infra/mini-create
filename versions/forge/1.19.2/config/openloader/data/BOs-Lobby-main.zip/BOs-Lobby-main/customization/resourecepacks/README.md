# Example Resource Pack for customization

This folder includes a basic resource pack which could be used for customization of the dimensions and/or the welcome messages used by the Lobby, Fishing and Mining Dimension mod.

## More Information

If you need more details about resource packs, please take a look at [Tutorials/Creating a resource pack](https://minecraft.fandom.com/wiki/Tutorials/Creating_a_resource_pack).
